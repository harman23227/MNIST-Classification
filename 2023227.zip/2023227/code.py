import os
import struct
import numpy as np
import matplotlib
matplotlib.use('Agg')  
import matplotlib.pyplot as plt
from array import array
from pathlib import Path
from numpy.linalg import pinv
from scipy.linalg import eigh


NUM_SAMPLES_PER_CLASS = 100
CLASSES = [0, 1, 2]
DATA_DIR = Path('.')


TRAIN_IMAGES_FILE = DATA_DIR / 'train-images-idx3-ubyte'
TRAIN_LABELS_FILE = DATA_DIR / 'train-labels-idx1-ubyte'
TEST_IMAGES_FILE = DATA_DIR / 't10k-images-idx3-ubyte'
TEST_LABELS_FILE = DATA_DIR / 't10k-labels-idx1-ubyte'

def read_images_labels(images_filepath, labels_filepath):

    with open(images_filepath, 'rb') as file:
        magic, size, rows, cols = struct.unpack(">IIII", file.read(16))
        image_data = array("B", file.read())

    with open(labels_filepath, 'rb') as file:
        magic, size = struct.unpack(">II", file.read(8))
        labels = array("B", file.read())

    images = np.zeros((size, rows * cols), dtype=np.float32)
    for i in range(size):
        img = np.array(image_data[i * rows * cols:(i + 1) * rows * cols])
        images[i] = img.reshape((rows * cols)) / 255.0  # Normalize to [0,1]

    return images, np.array(labels)

def select_samples(images, labels):

    selected_images = []
    selected_labels = []

    for digit in CLASSES:
        digit_indices = np.where(labels == digit)[0]
        sampled_indices = np.random.choice(digit_indices, NUM_SAMPLES_PER_CLASS, replace=False)
        selected_images.append(images[sampled_indices])
        selected_labels.append(labels[sampled_indices])

    return np.concatenate(selected_images), np.concatenate(selected_labels)

def compute_scatter_matrices(X, y, classes):
    
    n_features = X.shape[1]
    n_samples = X.shape[0]
    
    # Global mean (μ)
    mu = np.mean(X, axis=0)
    
    # Initialize scatter matrices
    Sb = np.zeros((n_features, n_features))
    Sw = np.zeros((n_features, n_features))
    
    # Compute class-wise statistics
    for c in classes:
        # Get samples for this class
        X_c = X[y == c]
        n_c = X_c.shape[0]
        
        # Compute class mean (μc)
        mu_c = np.mean(X_c, axis=0)
        
        # Update between-class scatter: Sb = Σc Nc(μc - μ)(μc - μ)T
        mu_diff = (mu_c - mu).reshape(-1, 1)
        Sb += n_c * np.dot(mu_diff, mu_diff.T)
        
        # Update within-class scatter: Sw = Σc Σxi∈Cc (xi - μc)(xi - μc)T
        X_centered = X_c - mu_c
        Sw += np.dot(X_centered.T, X_centered)
    
    return Sb, Sw

def custom_pca(X, n_components=None, variance_threshold=None):
   
    # Center the data
    mu = np.mean(X, axis=0)
    X_centered = X - mu
    
    # Compute covariance matrix: S = XcXc^T / (N-1)
    covar = np.dot(X_centered.T, X_centered) / (X.shape[0] - 1)
    
    # Compute eigenvalues and eigenvectors
    eigenvals, eigenvecs = eigh(covar)
    
    # Sort in descending order
    idx = np.argsort(eigenvals)[::-1]
    eigenvals = eigenvals[idx]
    eigenvecs = eigenvecs[:, idx]
    
    # Calculate variance ratios
    total_var = np.sum(eigenvals)
    variance_ratio = np.cumsum(eigenvals) / total_var
    
    # Determine number of components
    if variance_threshold is not None:
        n_components = np.argmax(variance_ratio >= variance_threshold) + 1
    elif n_components is None:
        n_components = X.shape[1]
    
    # Select components and project data
    W = eigenvecs[:, :n_components]
    X_transformed = np.dot(X_centered, W)
    
    return X_transformed, W, variance_ratio

def custom_fda(X, y, n_components):
    """
    Custom implementation of FDA following assignment requirements
    """
    # Compute scatter matrices
    Sb, Sw = compute_scatter_matrices(X, y, np.unique(y))
    
    # Add small regularization to Sw for stability (as suggested in class discussion)
    n = Sw.shape[0]
    Sw_reg = Sw + 0.001 * np.eye(n)
    
    # Compute Sw^-1 * Sb
    Sw_inv = pinv(Sw_reg)
    prod = np.dot(Sw_inv, Sb)
    
    # Make symmetric for numerical stability
    prod_sym = (prod + prod.T) / 2
    
    # Solve eigenvalue problem
    eigenvals, eigenvecs = eigh(prod_sym)
    
    # Sort in descending order
    idx = np.argsort(eigenvals)[::-1]
    eigenvals = eigenvals[idx]
    eigenvecs = eigenvecs[:, idx]
    
    # Select components and project data
    W = eigenvecs[:, :n_components]
    X_transformed = np.dot(X, W)
    
    return X_transformed, W

def custom_gaussian_classifier(X_train, y_train, X_test, classes, quadratic=False):
  
    predictions = []
    
    # Compute class-wise statistics
    class_stats = {}
    for c in classes:
        X_c = X_train[y_train == c]
        
        # MLE estimates
        mean_c = np.mean(X_c, axis=0)
        cov_c = np.dot((X_c - mean_c).T, (X_c - mean_c)) / len(X_c)
        
        if not quadratic:
            # For LDA, use pooled covariance
            cov_c = np.dot((X_train - np.mean(X_train, axis=0)).T, 
                          (X_train - np.mean(X_train, axis=0))) / len(X_train)
        
        class_stats[c] = {
            'mean': mean_c,
            'cov': cov_c,
            'prior': len(X_c) / len(X_train)
        }
    
    # Classify test points
    for x in X_test:
        scores = {}
        for c in classes:
            stats = class_stats[c]
            diff = x - stats['mean']
            
            # Compute log likelihood
            cov_inv = pinv(stats['cov'])
            log_det = np.log(np.linalg.det(stats['cov']) + 1e-10)
            
            log_likelihood = -0.5 * (np.dot(np.dot(diff, cov_inv), diff) + log_det)
            log_likelihood += np.log(stats['prior'])
            
            scores[c] = log_likelihood
        
        predictions.append(max(scores.items(), key=lambda x: x[1])[0])
    
    return np.array(predictions)

def evaluate_classifier(y_true, y_pred, class_names=None):

    accuracy = np.mean(y_true == y_pred)
    
    if class_names is None:
        class_names = [f"Class {i}" for i in range(len(np.unique(y_true)))]
    
    metrics = {
        'accuracy': accuracy,
        'per_class': {}
    }
    
    for i, class_name in enumerate(class_names):
        class_mask = y_true == i
        precision = np.sum((y_pred == i) & (y_true == i)) / np.sum(y_pred == i)
        recall = np.sum((y_pred == i) & (y_true == i)) / np.sum(y_true == i)
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
        metrics['per_class'][class_name] = {
            'precision': precision,
            'recall': recall,
            'f1': f1
        }
    
    return metrics

def apply_pca_with_variance(X_train, X_test, variance_threshold):

    X_train_pca, W, _ = custom_pca(X_train, variance_threshold=variance_threshold)
    X_test_pca = np.dot(X_test - np.mean(X_train, axis=0), W)
    return X_train_pca, X_test_pca, W

def apply_pca_fixed_components(X_train, X_test, n_components):

    X_train_pca, W, _ = custom_pca(X_train, n_components=n_components)
    X_test_pca = np.dot(X_test - np.mean(X_train, axis=0), W)
    return X_train_pca, X_test_pca, W

def apply_fda(X, y):

    n_components = len(np.unique(y)) - 1
    X_transformed, W = custom_fda(X, y, n_components=n_components)
    return X_transformed, W

def run_evaluation_pipeline(X_train, X_test, y_train, y_test):

    results = {}
    class_names = ['0', '1', '2']
    

    print("\n1. Direct FDA Application:")
    X_train_fda, fda_model = apply_fda(X_train, y_train)
    X_test_fda = np.dot(X_test, fda_model)
    

    print("Running LDA on FDA...")
    lda_train_pred = custom_gaussian_classifier(X_train_fda, y_train, X_train_fda, CLASSES, quadratic=False)
    lda_test_pred = custom_gaussian_classifier(X_train_fda, y_train, X_test_fda, CLASSES, quadratic=False)
    
    results['FDA_LDA'] = {
        'train': evaluate_classifier(y_train, lda_train_pred, class_names),
        'test': evaluate_classifier(y_test, lda_test_pred, class_names)
    }
    

    print("Running QDA on FDA...")
    qda_train_pred = custom_gaussian_classifier(X_train_fda, y_train, X_train_fda, CLASSES, quadratic=True)
    qda_test_pred = custom_gaussian_classifier(X_train_fda, y_train, X_test_fda, CLASSES, quadratic=True)
    
    results['FDA_QDA'] = {
        'train': evaluate_classifier(y_train, qda_train_pred, class_names),
        'test': evaluate_classifier(y_test, qda_test_pred, class_names)
    }
    

    print("\n2. PCA (95% variance) + LDA:")
    X_train_pca_95, X_test_pca_95, pca_95 = apply_pca_with_variance(X_train, X_test, 0.95)
    
    lda_pca95_train_pred = custom_gaussian_classifier(X_train_pca_95, y_train, X_train_pca_95, CLASSES, quadratic=False)
    lda_pca95_test_pred = custom_gaussian_classifier(X_train_pca_95, y_train, X_test_pca_95, CLASSES, quadratic=False)
    
    results['PCA95_LDA'] = {
        'train': evaluate_classifier(y_train, lda_pca95_train_pred, class_names),
        'test': evaluate_classifier(y_test, lda_pca95_test_pred, class_names)
    }
    

    print("\n3. PCA (90% variance) + LDA:")
    X_train_pca_90, X_test_pca_90, pca_90 = apply_pca_with_variance(X_train, X_test, 0.90)
    
    lda_pca90_train_pred = custom_gaussian_classifier(X_train_pca_90, y_train, X_train_pca_90, CLASSES, quadratic=False)
    lda_pca90_test_pred = custom_gaussian_classifier(X_train_pca_90, y_train, X_test_pca_90, CLASSES, quadratic=False)
    
    results['PCA90_LDA'] = {
        'train': evaluate_classifier(y_train, lda_pca90_train_pred, class_names),
        'test': evaluate_classifier(y_test, lda_pca90_test_pred, class_names)
    }
    

    print("\n4. PCA (2 components) + LDA:")
    X_train_pca_2, X_test_pca_2, pca_2 = apply_pca_fixed_components(X_train, X_test, 2)
    
    lda_pca2_train_pred = custom_gaussian_classifier(X_train_pca_2, y_train, X_train_pca_2, CLASSES, quadratic=False)
    lda_pca2_test_pred = custom_gaussian_classifier(X_train_pca_2, y_train, X_test_pca_2, CLASSES, quadratic=False)
    
    results['PCA2_LDA'] = {
        'train': evaluate_classifier(y_train, lda_pca2_train_pred, class_names),
        'test': evaluate_classifier(y_test, lda_pca2_test_pred, class_names)
    }
    
    return results, (X_train_pca_2, X_test_pca_2, pca_2)

def plot_results(results):

    methods = list(results.keys())
    train_acc = [results[m]['train']['accuracy'] for m in methods]
    test_acc = [results[m]['test']['accuracy'] for m in methods]
    
    x = np.arange(len(methods))
    width = 0.35
    
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.bar(x - width/2, train_acc, width, label='Train')
    ax.bar(x + width/2, test_acc, width, label='Test')
    
    ax.set_ylabel('Accuracy')
    ax.set_title('Classification Performance Comparison')
    ax.set_xticks(x)
    ax.set_xticklabels(methods, rotation=45)
    ax.legend()
    
    plt.tight_layout()
    plt.savefig('output/performance_comparison.png')
    plt.close()

def print_results(results):

    print("\nDetailed Results:")
    print("=" * 80)
    for method, metrics in results.items():
        print(f"\n{method}:")
        print(f"Train Accuracy: {metrics['train']['accuracy']:.3f}")
        print(f"Test Accuracy: {metrics['test']['accuracy']:.3f}")
        print("\nPer-class metrics (Test):")
        for class_name, class_metrics in metrics['test']['per_class'].items():
            print(f"\nClass {class_name}:")
            print(f"  Precision: {class_metrics['precision']:.3f}")
            print(f"  Recall: {class_metrics['recall']:.3f}")
            print(f"  F1-score: {class_metrics['f1']:.3f}")
        print("-" * 40)

def visualize_2d_data(X, y, title, filename):

    plt.figure(figsize=(10, 8))
    for i in np.unique(y):
        mask = y == i
        plt.scatter(X[mask, 0], X[mask, 1], label=f'Class {i}', alpha=0.6)
    
    plt.title(title)
    plt.xlabel('First Component')
    plt.ylabel('Second Component')
    plt.legend()
    plt.grid(True)
    plt.savefig(f'output/{filename}.png')
    plt.close()

def main():

    output_dir = Path('output')
    output_dir.mkdir(exist_ok=True)
    

    print("Loading data...")
    x_train, y_train = read_images_labels(TRAIN_IMAGES_FILE, TRAIN_LABELS_FILE)
    x_test, y_test = read_images_labels(TEST_IMAGES_FILE, TEST_LABELS_FILE)
    

    print("Selecting samples...")
    X_train, y_train = select_samples(x_train, y_train)
    X_test, y_test = select_samples(x_test, y_test)
    

    X_train = X_train.astype(np.float32) / 255.0
    X_test = X_test.astype(np.float32) / 255.0
    

    print("Running evaluation pipeline...")
    results, pca_data = run_evaluation_pipeline(X_train, X_test, y_train, y_test)
    

    print_results(results)
    plot_results(results)
    

    X_train_pca_2, X_test_pca_2, _ = pca_data
    X_train_fda, fda_model = apply_fda(X_train, y_train)
    X_test_fda = np.dot(X_test, fda_model)
    
    visualize_2d_data(X_train_pca_2, y_train, 'PCA Transformation (Training Data)', 'pca_train_visualization')
    visualize_2d_data(X_test_pca_2, y_test, 'PCA Transformation (Test Data)', 'pca_test_visualization')
    visualize_2d_data(X_train_fda, y_train, 'FDA Transformation (Training Data)', 'fda_train_visualization')
    visualize_2d_data(X_test_fda, y_test, 'FDA Transformation (Test Data)', 'fda_test_visualization')

if __name__ == "__main__":
    main()
